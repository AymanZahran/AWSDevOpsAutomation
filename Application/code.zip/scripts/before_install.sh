#!/bin/bash
rm -rf /var/www
yum install -y httpd
